import Stripe from 'stripe';
import { buffer } from 'micro';
import { adminDb } from '../../lib/firebaseAdmin';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
export const config = { api:{ bodyParser:false } };

export default async function handler(req,res){
  if (req.method!=='POST') return res.status(405).end('Method Not Allowed');
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const buf = await buffer(req);
  let event;
  try {
    event = webhookSecret ? stripe.webhooks.constructEvent(buf.toString(), sig, webhookSecret) : JSON.parse(buf.toString());
  } catch(e){ console.error('webhook parse error', e); return res.status(400).send('err'); }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.metadata?.userId || null;
    const referralCode = session.metadata?.referralCode || null;
    if (userId) await adminDb.collection('users').doc(userId).set({ subscriptionStatus:'active', stripeCustomerId: session.customer || null, lastCheckoutSession: session.id, updatedAt: new Date().toISOString() }, { merge:true });
    await adminDb.collection('subscriptions').add({ sessionId: session.id, userId: userId || null, referralCode, createdAt: new Date().toISOString() });
  }
  res.json({ received: true });
}
