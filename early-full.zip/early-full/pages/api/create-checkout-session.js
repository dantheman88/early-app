import Stripe from 'stripe';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req,res){
  if (req.method!=='POST') return res.status(405).end('Method Not Allowed');
  const { userId, referralCode } = req.body || {};
  const priceId = process.env.STRIPE_PRICE_ID;
  if (!priceId) return res.status(500).json({ error: 'Missing price id' });
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items:[{ price: priceId, quantity:1 }],
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/`,
      metadata: { userId: userId || '', referralCode: referralCode || '' }
    });
    res.json({ url: session.url, id: session.id });
  } catch(e) { console.error(e); res.status(500).json({ error: 'Stripe error' }); }
}
