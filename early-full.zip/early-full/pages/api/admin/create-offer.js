import { adminDb, adminApp } from '../../../lib/firebaseAdmin';

export default async function handler(req,res){
  if (req.method!=='POST') return res.status(405).end('Method Not Allowed');
  const authHeader = req.headers.authorization || '';
  const match = authHeader.match(/^Bearer (.+)$/);
  if (!match) return res.status(401).json({ error: 'Missing token' });
  try {
    const idToken = match[1];
    const decoded = await adminApp.auth().verifyIdToken(idToken);
    const uid = decoded.uid;
    const allowed = (process.env.ADMIN_UIDS || '').split(',').map(s=>s.trim()).filter(Boolean);
    if (allowed.length && !allowed.includes(uid)) return res.status(403).json({ error: 'Not admin' });
    const { title, payout } = req.body;
    const docRef = await adminDb.collection('offers').add({ title, payout: Number(payout||0), createdAt: new Date().toISOString(), conversions:0 });
    res.json({ ok:true, id: docRef.id });
  } catch(e) {
    console.error(e);
    res.status(401).json({ error: 'Invalid token' });
  }
}
