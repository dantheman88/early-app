import { adminDb } from '../../lib/firebaseAdmin';
const fetch = require('node-fetch');

export default async function handler(req,res){
  if (req.method!=='POST') return res.status(405).end('Method Not Allowed');
  const { title, body } = req.body || {};
  if (!title || !body) return res.status(400).json({ error:'title and body required' });
  try {
    const snaps = await adminDb.collection('users').get();
    const messages = [];
    snaps.forEach(d => { const data = d.data(); if (data.pushToken) messages.push({ to: data.pushToken, title, body, data:{ sentAt: new Date().toISOString() } }); });
    for (let i=0;i<messages.length;i+=100) {
      const chunk = messages.slice(i,i+100);
      await fetch('https://exp.host/--/api/v2/push/send', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(chunk) });
    }
    res.json({ ok:true, sent: messages.length });
  } catch(e){ console.error(e); res.status(500).json({ error:'internal' }); }
}
