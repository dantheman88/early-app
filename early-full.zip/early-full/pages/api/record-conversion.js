import { adminDb, adminApp } from '../../lib/firebaseAdmin';

export default async function handler(req,res){
  if (req.method!=='POST') return res.status(405).end('Method Not Allowed');
  const { offerId, userId, amount, referralCode } = req.body || {};
  if (!offerId || !amount) return res.status(400).json({ error: 'offerId and amount required' });
  try {
    const convRef = await adminDb.collection('conversions').add({ offerId, userId: userId || null, amount: Number(amount), referralCode: referralCode || null, event:'conversion', createdAt: new Date().toISOString() });
    if (userId) await adminDb.collection('users').doc(userId).set({ balance: adminApp.firestore.FieldValue.increment(Number(amount)) }, { merge:true });
    if (referralCode) {
      const q = await adminDb.collection('users').where('referralCode','==', referralCode).limit(1).get();
      if (!q.empty) {
        const refUser = q.docs[0];
        const bonus = Number(amount) * 0.1;
        await adminDb.collection('users').doc(refUser.id).set({ balance: adminApp.firestore.FieldValue.increment(bonus) }, { merge:true });
      }
    }
    await adminDb.collection('offers').doc(offerId).update({ conversions: adminApp.firestore.FieldValue.increment(1) });
    res.json({ ok:true, id: convRef.id });
  } catch(e){ console.error(e); res.status(500).json({ error:'internal' }); }
}
