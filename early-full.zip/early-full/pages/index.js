import Link from 'next/link';
import { listOffers } from '../lib/helpers';

export default function Home({ user }) {
  const offers = [];
  return (
    <div>
      <h1>Early — Discover micro-opportunities</h1>
      <p>Welcome{user ? ' ' + user.email : ''}.</p>
      <Link href='/admin'><a>Admin</a></Link>
    </div>
  );
}
