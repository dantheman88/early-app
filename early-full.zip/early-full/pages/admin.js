import { useState } from 'react';
import { auth } from '../lib/firebase';

export default function Admin({ user }) {
  const [title, setTitle] = useState('');
  const create = async (e) => {
    e.preventDefault();
    if (!auth.currentUser) return alert('sign in as admin');
    const token = await auth.currentUser.getIdToken();
    const res = await fetch('/api/admin/create-offer', { method:'POST', headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer ' + token }, body: JSON.stringify({ title, payout: 5 })});
    const j = await res.json();
    if (res.ok) alert('Created ' + j.id); else alert('Error: ' + j.error);
  };
  return (
    <div>
      <h1>Admin</h1>
      <form onSubmit={create}>
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Offer title" />
        <button type="submit">Create</button>
      </form>
    </div>
  );
}
