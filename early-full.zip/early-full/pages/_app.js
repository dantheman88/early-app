import '../styles/globals.css';
import { useEffect, useState } from 'react';
import { auth, googleProvider } from '../lib/firebase';
import { onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import Header from '../components/Header';

function MyApp({ Component, pageProps }) {
  const [user, setUser] = useState(null);
  useEffect(() => {
    return onAuthStateChanged(auth, u => {
      if (u) setUser({ uid: u.uid, email: u.email, name: u.displayName });
      else setUser(null);
    });
  }, []);
  const signIn = async () => { try { await signInWithPopup(auth, googleProvider); } catch(e){} };
  const signOutUser = async () => { await signOut(auth); };
  return <>
    <Header user={user} onSignOut={signOutUser} />
    <main style={{ padding: 20 }}><Component {...pageProps} user={user} signIn={signIn} /></main>
  </>;
}
export default MyApp;
