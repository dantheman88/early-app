import React, { useEffect, useState } from 'react';
import { Text, View, FlatList, TouchableOpacity, Button, Linking, TextInput, Alert } from 'react-native';
import Constants from 'expo-constants';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, getDocs, addDoc } from 'firebase/firestore';

const FIREBASE_CONFIG = {
  apiKey: Constants.manifest.extra.FIREBASE_API_KEY || '',
  authDomain: Constants.manifest.extra.FIREBASE_AUTH_DOMAIN || '',
  projectId: Constants.manifest.extra.FIREBASE_PROJECT_ID || '',
  storageBucket: Constants.manifest.extra.FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: Constants.manifest.extra.FIREBASE_MESSAGING_SENDER_ID || '',
  appId: Constants.manifest.extra.FIREBASE_APP_ID || ''
};
try { initializeApp(FIREBASE_CONFIG); } catch(e) {}
const auth = getAuth();
const db = getFirestore();

export default function App() {
  const [offers, setOffers] = useState([]);
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const [user,setUser]=useState(null);
  useEffect(()=>{ loadOffers(); const unsub = onAuthStateChanged(auth,u=>{ setUser(u?{uid:u.uid,email:u.email}:null); }); return ()=>unsub(); },[]);
  async function loadOffers(){ const snaps=await getDocs(collection(db,'offers')); setOffers(snaps.docs.map(d=>({id:d.id,...d.data()}))); }
  async function openOffer(o){ await addDoc(collection(db,'conversions'), { offerId:o.id, userId: user? user.uid:null, event:'click', createdAt: new Date().toISOString() }); Linking.openURL(o.affiliateUrl||o.url||'https://example.com'); }
  async function signup(){ try{ await createUserWithEmailAndPassword(auth,email,password); Alert.alert('Signed up'); }catch(e){Alert.alert(e.message)} }
  async function login(){ try{ await signInWithEmailAndPassword(auth,email,password); Alert.alert('Signed in'); }catch(e){Alert.alert(e.message)} }
  return (<View style={{padding:20}}><Text style={{fontSize:24}}>Early Mobile</Text>
    <View style={{marginVertical:8}}><TextInput placeholder="email" value={email} onChangeText={setEmail} /><TextInput secureTextEntry placeholder="password" value={password} onChangeText={setPassword} /></View>
    <View style={{flexDirection:'row',gap:8}}><Button title="Sign Up" onPress={signup} /><Button title="Sign In" onPress={login} /></View>
    <FlatList data={offers} keyExtractor={i=>i.id} renderItem={({item})=>(<TouchableOpacity onPress={()=>openOffer(item)} style={{padding:12,background:'#eee',marginVertical:6}}><Text style={{fontWeight:'700'}}>{item.title}</Text><Text>${item.payout}</Text></TouchableOpacity>)} />
  </View>);
}
