# Early — Full Stack Next.js + Firebase + Stripe Starter

This repo is a full-featured starter for the Early app:
- Next.js frontend
- Firebase client (Auth + Firestore)
- Firebase Admin (server)
- Stripe Checkout + webhook
- Admin protected API (create offers)
- Conversion recording & wallet credits
- Expo mobile scaffold (in /mobile)

See .env.example for required environment variables and follow README_DEPLOY.md for deployment steps.
